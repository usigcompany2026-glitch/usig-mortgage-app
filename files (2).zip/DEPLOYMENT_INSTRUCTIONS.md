# USIG Mortgage PWA - Full Deployment Guide (Option B)

## Files You Have
✅ index.html - Form UI  
✅ styles.css - Navy/Gold styling  
✅ app.js - Form logic + GHL webhook  
✅ manifest.json - PWA config  
✅ netlify-submit-lead.js - Backend serverless function  
✅ netlify.toml - Netlify configuration  
✅ package.json - Dependencies  

---

## Deployment Path: GitHub → Netlify

### STEP 1: Create GitHub Account (If You Don't Have One)
1. Go to **github.com**
2. Click **Sign up**
3. Enter email, password, username
4. Verify email
5. Done ✓

### STEP 2: Create GitHub Repository
1. Go to **github.com** (logged in)
2. Click **+** icon (top right) → **New repository**
3. **Repository name:** `usig-mortgage-pwa`
4. **Description:** USIG Mortgage Lead Capture
5. **Public** (so Netlify can access it)
6. Check **Add a README file**
7. Click **Create repository** ✓

### STEP 3: Upload Your Files to GitHub
1. In your new repo, click **Add file** → **Upload files**
2. Download these files from Claude:
   - index.html
   - styles.css
   - app.js
   - manifest.json
   - netlify.toml
   - package.json
   - netlify-submit-lead.js

3. **Important:** Create a folder structure:
   - **netlify/** (folder)
     - **functions/** (subfolder)
       - netlify-submit-lead.js (put HERE)

4. Upload all other files to ROOT:
   - index.html (ROOT)
   - styles.css (ROOT)
   - app.js (ROOT)
   - manifest.json (ROOT)
   - netlify.toml (ROOT)
   - package.json (ROOT)

5. Click **Commit changes** ✓

### STEP 4: Connect GitHub to Netlify
1. Go to **netlify.com**
2. Click **Sign up** (or sign in if you have account)
3. Choose **Sign up with GitHub**
4. Authorize Netlify to access your GitHub
5. You'll see your repositories
6. Click **Deploy site** next to `usig-mortgage-pwa`
7. Choose:
   - **Branch to deploy:** main
   - **Build command:** (leave blank, Netlify will auto-detect)
   - **Publish directory:** . (current directory)
8. Click **Deploy site** ✓

### STEP 5: Set Environment Variables in Netlify
1. In Netlify, go to your **usig-mortgage-pwa** site
2. Click **Settings** → **Build & deploy** → **Environment**
3. Click **Edit variables**
4. Add these 5 environment variables:

| Variable Name | Value |
|---|---|
| `GHL_API_KEY` | Your GHL API key (from GHL Settings → API) |
| `TWILIO_ACCOUNT_SID` | Your Twilio Account SID (from Twilio Console) |
| `TWILIO_AUTH_TOKEN` | Your Twilio Auth Token (from Twilio Console) |
| `TWILIO_FROM_NUMBER` | Your Twilio phone number (e.g., +15551234567) |
| `BRENDA_PHONE` | +13104248338 |

5. Click **Save** ✓

### STEP 6: Deploy
1. Netlify will automatically deploy when you added environment variables
2. You'll see a **Deploy log** showing:
   - Building...
   - Function: submit-lead detected
   - Deploy complete ✓

3. You'll get a URL like: `https://usig-mortgage-pwa.netlify.app`

---

## Testing the Deployment

1. Visit your Netlify URL
2. You should see:
   - Navy blue header with GOLD "USIG" text ✓
   - Mortgage form with all fields ✓
   - Professional styling ✓

3. Fill out the form and click **Submit**
4. Should see: "Your mortgage inquiry has been received" ✓
5. Check your GHL Contacts - new lead should appear ✓
6. Check your phone (Brenda's) for SMS notification ✓

---

## Environment Variables - Where to Find Them

**GHL API Key:**
- Go to **GoHighLevel** (gohighlevel.com)
- Settings → API Keys
- Copy the API key

**Twilio Credentials:**
- Go to **Twilio Console** (console.twilio.com)
- Account → API keys & tokens
- Copy Account SID, Auth Token
- Phone Numbers → Manage Numbers
- Copy your Twilio phone number

---

## Troubleshooting

**Form doesn't submit?**
- Check browser console (F12) for errors
- Verify environment variables are set in Netlify
- Check Netlify Function logs

**GHL contact not created?**
- Verify GHL_API_KEY is correct
- Check Netlify Function logs for API errors

**SMS not sending?**
- Verify Twilio credentials
- Verify BRENDA_PHONE format: +13104248338

**Check Netlify Logs:**
- In Netlify site dashboard
- Click **Functions** → **submit-lead**
- View real-time logs

---

## Done!

Once deployed and working:
- ✅ Form loads on custom domain
- ✅ Leads flow to GHL
- ✅ SMS alerts to Brenda
- ✅ AI conversation workflows start
- ✅ Lead scoring (WARM/COLD) applied

**Next:** Set custom domain (usig-mortgage.usig.ai) in Netlify
