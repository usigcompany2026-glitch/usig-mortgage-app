# USIG Mortgage App - Deployment Guide

## What You Have
✅ React Native + Expo app (works on web, iOS, Android)
✅ Professional mortgage lead form
✅ GHL integration
✅ SMS notifications
✅ Cross-platform (Web + Mobile)

---

## QUICK START (5 Minutes)

### 1. Install Expo CLI
```bash
npm install -g expo-cli
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Locally
```bash
# Web
expo start --web

# iOS (Mac only)
expo start --ios

# Android
expo start --android
```

---

## Deploy to Production

### Option A: Web (Netlify) + Mobile (Expo)

#### Step 1: Push to GitHub
1. Create GitHub repo: `usig-mortgage-app`
2. Push code:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/usig-mortgage-app.git
git push -u origin main
```

#### Step 2: Deploy Web to Netlify
1. Go to netlify.com
2. **Import from Git** → Choose GitHub repo
3. Build command: `echo 'done'`
4. Publish directory: `.`
5. Deploy

#### Step 3: Add Environment Variables
In Netlify Settings → Environment:
```
GHL_API_KEY = [Your GHL API key]
TWILIO_ACCOUNT_SID = [Your Twilio SID]
TWILIO_AUTH_TOKEN = [Your Twilio Token]
TWILIO_FROM_NUMBER = [Your Twilio number]
BRENDA_PHONE = +13104248338
```

#### Step 4: Mobile (Expo)
Share with team using Expo:
```bash
expo start

# Scan QR code with Expo Go app on phone
# iOS: Apple App Store → Search "Expo Go"
# Android: Google Play → Search "Expo Go"
```

---

## Environment Variables (Required)

| Variable | Where to Find |
|---|---|
| GHL_API_KEY | GoHighLevel → Settings → API Keys |
| TWILIO_ACCOUNT_SID | Twilio Console → Account SID |
| TWILIO_AUTH_TOKEN | Twilio Console → Auth Token |
| TWILIO_FROM_NUMBER | Twilio → Phone Numbers |
| BRENDA_PHONE | +13104248338 |

---

## Testing

1. **Local:** `expo start --web`
2. **Mobile:** Scan QR code with Expo Go
3. **Web:** Visit Netlify URL
4. **Fill form** → **Submit**
5. **Check GHL Contacts** ✓
6. **Check SMS on phone** ✓

---

## Troubleshooting

**Form won't submit?**
- Check browser console (F12)
- Verify environment variables in Netlify
- Check Netlify Function logs

**No SMS received?**
- Verify TWILIO_FROM_NUMBER is correct
- Verify BRENDA_PHONE format: +13104248338

**Dropdowns not working?**
- Close app, hard refresh
- On mobile: Kill Expo Go app, reopen

---

## Done!

Your app is now:
✅ Live on web (Netlify)
✅ Available on mobile (Expo Go)
✅ Submitting to GHL
✅ Sending SMS alerts
✅ Professional & production-ready

